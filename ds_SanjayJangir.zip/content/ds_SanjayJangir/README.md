
# 📊 Data Science Project: Fear & Greed Index vs Trading Metrics

## 📋 Project Overview
This project analyzes the impact of **market sentiment** (measured using the **Fear & Greed Index**) on key trading metrics from historical futures trading data.

By combining market sentiment indicators with actual trade outcomes, this analysis aims to uncover whether **extreme fear or greed** influences trading behavior, volumes, profitability, and other metrics.

---

## 🎯 Project Objectives
- ✅ Clean and preprocess historical trade and sentiment datasets.
- ✅ Merge datasets by date for integrated analysis.
- ✅ Visualize relationships between Fear & Greed Index and trading metrics.
- ✅ Conduct statistical tests to quantify sentiment effects:
  - Pearson Correlation
  - T-tests (Fear vs Greed periods)
- ✅ Identify leading/lagging relationships via **rolling cross-correlation** analysis.

---

## 📂 Folder Structure
ds_SanjayJangir/
├── notebook_1.ipynb
├── csv_files/
│ └── daily_metrics.csv
├── outputs/
│ └── *.png (visualizations)
├── ds_report.pdf
└── README.md

---

## 📊 Datasets Used
1. **Fear & Greed Index Data**  
2. **Historical Trading Data**

---

## ⚙️ How to Run This Project
1. Upload datasets to `/content/` directory in Google Colab.
2. Open and run **notebook_1.ipynb**:
   - Generates outputs automatically.
3. Review `ds_report.pdf` for conclusions.

---

## 📈 Key Insights (From Analysis)
- Sentiment-driven market behavior patterns observed.
- Volume & profitability strongly linked to sentiment.
- Lagged effects visible via rolling cross-correlation.

---

## ✍️ Author
**Sanjay Jangir**  
Data Science Project — IIT Kanpur

---

## ✅ Notes:
This project is fully compatible with **Google Colab** and **Google Drive** workflows.
